sleep 2 # wait a bit for docker to setup

docker-compose exec -T clickhouse01 clickhouse-client -m -n < sample_sales.sql

docker-compose exec -T clickhouse01 clickhouse-client -q 'INSERT INTO sampledb.sale_records FORMAT CSV' < sample_sales.csv	
