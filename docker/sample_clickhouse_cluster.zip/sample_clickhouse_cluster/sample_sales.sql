CREATE DATABASE IF NOT EXISTS sampledb ON CLUSTER company_cluster;

CREATE TABLE IF NOT EXISTS sampledb.sale_records_shard ON CLUSTER company_cluster
(
    `Country` Nullable(String),
    `Item_Type` Nullable(String),
    `Order_Date` Nullable(DateTime),
    `Order_ID` Nullable(Int64),
    `Order_Priority` Nullable(String),
    `Region` Nullable(String),
    `Sales_Channel` Nullable(String),
    `Ship_Date` Nullable(DateTime),
    `Total_Cost` Nullable(Float64),
    `Total_Profit` Nullable(Float64),
    `Total_Revenue` Nullable(Float64),
    `Unit_Cost` Nullable(Float64),
    `Unit_Price` Nullable(Float64),
    `Units_Sold` Nullable(Int32)
)
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{cluster}/{shard}/sampledb/sale_records', '{replica}')
ORDER BY tuple()
SETTINGS index_granularity = 8192;
	

CREATE TABLE IF NOT EXISTS sampledb.sale_records ON CLUSTER company_cluster
(
    `Country` Nullable(String),
    `Item_Type` Nullable(String),
    `Order_Date` Nullable(DateTime),
    `Order_ID` Nullable(Int64),
    `Order_Priority` Nullable(String),
    `Region` Nullable(String),
    `Sales_Channel` Nullable(String),
    `Ship_Date` Nullable(DateTime),
    `Total_Cost` Nullable(Float64),
    `Total_Profit` Nullable(Float64),
    `Total_Revenue` Nullable(Float64),
    `Unit_Cost` Nullable(Float64),
    `Unit_Price` Nullable(Float64),
    `Units_Sold` Nullable(Int32)
)
ENGINE = Distributed('company_cluster', 'sampledb', 'sale_records_shard', rand());
